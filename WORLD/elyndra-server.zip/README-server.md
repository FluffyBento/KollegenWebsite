# Elyndra-Server — Setup & Betrieb

Das ist der lauffähige Server aus `backend-architektur.md`: Node.js + Socket.io + PostgreSQL,
autoritative Spiellogik (Kampf, Sammeln, Handel, Auktionshaus, Reiche), an euren bestehenden
Website-Login gekoppelt. Die Spieldaten (Items/Monster/Skillbäume/Zonen) sind 1:1 aus dem
Client-Prototyp extrahiert (`src/gameData.generated.json`) — nie von Hand zweimal pflegen.

## 1. Voraussetzungen

- Node.js ≥ 18 (wegen des eingebauten `fetch`)
- Eine PostgreSQL-Datenbank (lokal oder gehostet)

## 2. Installation

```bash
cd server
npm install
cp .env.example .env
# .env ausfüllen: DATABASE_URL, ELYNDRA_JWT_SECRET, SERVICE_SECRET (siehe unten)
npm run migrate
```

`ELYNDRA_JWT_SECRET` muss **identisch** mit dem Secret sein, mit dem eure bestehende Website
später die Login-Tokens signiert (siehe `backend-architektur.md`, Abschnitt 3). Für den Anfang
einfach einen langen Zufallswert eintragen — ihr braucht denselben Wert dann auf Website-Seite.

## 3. Lokal starten & testen (ganz ohne eure Website)

```bash
npm start
# in einem zweiten Terminal:
npm run gen-dev-token -- Testheld
```

Das gibt euch ein gültiges Test-JWT aus, wie es später die Website ausstellen würde. Damit
könnt ihr euch z. B. mit einem kleinen Socket.io-Client-Skript oder direkt aus dem Browser
(DevTools-Konsole) verbinden:

```js
const socket = io("http://localhost:4000", { auth: { token: "DAS_TOKEN_VON_OBEN" } });
socket.on("zone:state", console.log);
socket.on("connect_error", console.error);
```

`GET /health` zeigt, ob der Server läuft und die DB erreichbar ist.

## 4. Spieldaten aktuell halten

Wenn ihr am Client (`elyndra-online-prototyp.html` bzw. dessen `game.js`/`zones.js`-Quellen)
Items, Monster, Skillbäume, Zonen usw. ändert, lauft danach:

```bash
node scripts/extract-game-data.js /pfad/zu/game.js /pfad/zu/zones.js
```

Das schreibt `src/gameData.generated.json` neu — Client und Server bleiben so immer synchron,
ohne dass jemand zwei Kopien der Datentabellen pflegen muss.

## 5. Anbindung an eure Website

- **Login:** Website stellt beim Öffnen des Spiels ein JWT `{ userId, username }` aus
  (signiert mit `ELYNDRA_JWT_SECRET`), der Client übergibt es beim Verbinden als
  `auth: { token }`. Kein eigenes Passwort-System im Game-Server.
- **Punkte-Umtausch:** `WEBSITE_POINTS_URL` auf euren echten internen Endpunkt setzen
  (Vertrag in `backend-architektur.md`, Abschnitt 4). Ohne gesetzte URL wird der Umtausch nur
  simuliert (für Tests) — dann `MOCK_POINTS_ENDPOINT=true` lassen, um Anfragen lokal zu sehen.
- **CORS:** `ALLOWED_ORIGIN` auf eure tatsächliche Domain setzen, bevor ihr live geht.

## 6. Event-Vertrag zwischen Client und Server

Das ist die Schnittstelle, gegen die der Browser-Client umgebaut werden müsste, um wirklich
in Echtzeit mit anderen zu spielen (aktuell läuft der Prototyp ja rein lokal + `window.storage`).

**Client → Server** (`socket.emit(name, payload, ackCallback?)`)

| Event | Payload | Antwort (ack) |
|---|---|---|
| `player:move` | `{x,y,facing}` | – (fire-and-forget, wird gedrosselt/validiert) |
| `zone:change` | `{targetZone, spawn?}` | `{ok, zone}` |
| `combat:attack` | – | `{ok, hits:[...]}` |
| `combat:useSkill` | `{skillId}` | `{ok, hits/heal, ...}` |
| `gather:harvest` | `{resourceId}` | `{ok, item, qty}` |
| `inventory:equip` | `{slot, itemId}` | `{ok, equipment}` |
| `inventory:unequip` | `{slot}` | `{ok, equipment}` |
| `inventory:useConsumable` | `{itemId}` | `{ok, hp, hunger, thirst}` |
| `character:allocateAttr` | `{attr, delta:1|-1}` | `{ok, attrs, attr_points}` |
| `skills:unlock` | `{skillId}` | `{ok, skill_points, unlocked_skills, hotbar}` |
| `skills:assignHotbar` | `{slot, skillId|null}` | `{ok, hotbar}` |
| `craft:make` | `{recipeId}` | `{ok, result, qty}` |
| `shop:buy` / `shop:sell` | `{shopId,itemId}` / `{itemId,qty}` | `{ok, gold, ...}` |
| `auction:browse` | – | `{ok, listings}` |
| `auction:list` | `{itemId,qty,price}` | `{ok, listingId}` |
| `auction:buy` / `auction:cancel` | `{listingId}` | `{ok, ...}` |
| `bounty:claim` | `{bountyId}` | `{ok, gold, xp, level}` |
| `dailychest:open` | – | `{ok, gold, item, qty}` |
| `realm:build` | `{gx,gy,itemId\|null}` | `{ok, removedItem, placed}` |
| `realm:visit` | `{name}` | `{ok, ownerId, ownerName, objects}` |
| `economy:exchangeLumen` | `{amount}` | `{ok, points, spend}` |
| `mailbox:claim` | – | `{ok, entries}` |
| `chat:message` | `"text"` | – |

**Server → Client** (`socket.on(name, ...)`)

| Event | Bedeutung |
|---|---|
| `zone:state` | Vollständiger Snapshot beim Betreten einer Zone: Monster, Rohstoffe, andere Spieler, eigener Charakter |
| `player:joined` / `player:moved` / `player:left` | Andere Spieler in derselben Zone |
| `combat:hits` | Ergebnis eines Angriffs (auch von anderen Spielern), zum Anzeigen von Schadenszahlen |
| `vitals:update` | Serverseitig berechnete HP/MP/Ausdauer/Hunger/Durst — **maßgeblich**, Client sollte lokale Werte danach ausrichten statt selbst zu rechnen |
| `world:event` | Sonstige Weltereignisse (Boss erwacht, Monster respawnt, …) |
| `zone:discovered` / `achievements:unlocked` | Für Toasts im UI |
| `mailbox:claimed` | Auszahlungen beim Login |
| `realm:updated` | Live-Update, während jemand ein fremdes Reich besucht |
| `chat:message` | `{from, text, ts}` |
| `fatal:error` | Verbindung wird geschlossen (z. B. Charakter konnte nicht geladen werden) |

## 7. Bewusste Vereinfachungen (v0.1)

- Monster-/Rohstoff-Zustand lebt nur im Arbeitsspeicher des Prozesses (nicht in Redis) — bei
  einem Neustart setzt sich die Welt zurück. Für einen einzelnen Node-Prozess unproblematisch;
  bei mehreren Prozessen/Instanzen bräuchtet ihr Redis oder eine geteilte Welt-Autorität.
  Charakter-/Wirtschaftsdaten (Inventar, Gold, Auktionen, Reiche, …) sind dagegen immer in
  PostgreSQL und überleben Neustarts.
- Bewegungs-Anti-Cheat ist ein grobes Tempo-Limit, kein echtes Server-Rewind/Lag-Compensation.
- `realm:visit` liefert einen einmaligen Snapshot + tritt einer Live-Update-Room bei; es gibt
  noch keine Zugriffsprüfung gegen eure echte Freundesliste (aktuell kann jeder jeden Namen
  besuchen, wie im Browser-Prototyp).
