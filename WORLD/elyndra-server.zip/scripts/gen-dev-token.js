"use strict";
/**
 * Erzeugt ein Test-JWT, wie es in Produktion eure bestehende Website beim
 * Öffnen des Spiels ausstellen würde. Nur für lokale Entwicklung/Tests
 * gedacht — niemals mit diesem Skript Tokens für echte Nutzer erzeugen.
 *
 * Nutzung:
 *   node scripts/gen-dev-token.js <username> [userId]
 *
 * Braucht dieselbe ELYNDRA_JWT_SECRET wie der Server (aus .env).
 */
require("dotenv").config();
const jwt = require("jsonwebtoken");

const username = process.argv[2] || "Testheld";
const userId = process.argv[3] || "dev-" + Math.random().toString(36).slice(2, 8);

if (!process.env.ELYNDRA_JWT_SECRET) {
  console.error("ELYNDRA_JWT_SECRET fehlt — bitte .env aus .env.example anlegen und Secret setzen.");
  process.exit(1);
}

const token = jwt.sign(
  { userId, username },
  process.env.ELYNDRA_JWT_SECRET,
  { algorithm: "HS256", expiresIn: "6h" }
);

console.log("userId: ", userId);
console.log("username:", username);
console.log("token:   ", token);
console.log("\nIm Client-Handshake verwenden:");
console.log(`  io("http://localhost:${process.env.PORT || 4000}", { auth: { token: "${token}" } })`);
