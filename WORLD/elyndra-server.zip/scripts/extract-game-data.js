"use strict";
/**
 * Extrahiert die reinen Datentabellen (ITEMS, RECIPES, MONSTERS, SKILL_TREES,
 * BOUNTIES, ZONES, SHOPS) direkt aus der Client-Datei und schreibt sie nach
 * src/gameData.generated.json. So bleiben Client und Server garantiert in Sync,
 * ohne dass irgendwer die Daten von Hand zweimal pflegen muss.
 *
 * Nutzung:
 *   node scripts/extract-game-data.js /pfad/zu/game.js /pfad/zu/zones.js
 *
 * Hinweis: game.js/zones.js sind die reinen Datendateien aus dem Client-
 * Prototyp (nicht die komplette elyndra-online-prototyp.html). Falls du nur
 * die HTML-Datei hast, kopiere zuerst den <script>-Inhalt in game.js/zones.js
 * oder frag im Chat nach den separaten Quelldateien.
 */
const fs = require("fs");
const path = require("path");

const gameJsPath = process.argv[2];
const zonesJsPath = process.argv[3];

if (!gameJsPath || !zonesJsPath) {
  console.error("Nutzung: node scripts/extract-game-data.js <game.js> <zones.js>");
  process.exit(1);
}

// game.js/zones.js schreiben ihre Daten nach `window.ELYNDRA_DATA` — wir
// stellen dafür nur ein minimales `window`-Objekt bereit und lassen die
// Dateien unverändert laufen (sie enthalten reine Datenstrukturen + ein paar
// Hilfsfunktionen, kein DOM-Zugriff).
global.window = {};
require(path.resolve(gameJsPath));
require(path.resolve(zonesJsPath));

const D = global.window.ELYNDRA_DATA;
if (!D) {
  console.error("Konnte window.ELYNDRA_DATA nicht finden — falsche Datei(en)?");
  process.exit(1);
}

const payload = {
  ITEMS: D.ITEMS,
  RECIPES: D.RECIPES,
  MONSTERS: D.MONSTERS,
  SKILL_TREES: D.SKILL_TREES,
  BOUNTIES: D.BOUNTIES,
  ZONES: D.ZONES,
  SHOPS: D.SHOPS,
  RARITY_COLOR: D.RARITY_COLOR,
  RARITY_LABEL: D.RARITY_LABEL
};

const outPath = path.join(__dirname, "..", "src", "gameData.generated.json");
fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));
console.log("Geschrieben:", outPath, "(" + JSON.stringify(payload).length + " Bytes)");
console.log("Items:", Object.keys(payload.ITEMS).length, "· Monster:", Object.keys(payload.MONSTERS).length,
  "· Skillbäume:", Object.keys(payload.SKILL_TREES).length, "· Zonen:", Object.keys(payload.ZONES).length);
