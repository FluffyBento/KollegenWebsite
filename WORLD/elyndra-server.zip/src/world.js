"use strict";
const { MONSTERS, ZONES } = require("./gameData");

const AGGRO_RANGE = 175, MONSTER_ATTACK_RANGE = 32;
const RESPAWN_MS = 25000, ELITE_RESPAWN_MS = 75000, BOSS_RESPAWN_MS = 60000;
const HARVEST_COOLDOWN_MS = 26000;

// zoneId -> { monsters: [...], resources: [...], players: Map<socketId, {...}>, bossSpawned: bool }
const world = {};

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

function ensureZone(zoneId) {
  if (world[zoneId]) return world[zoneId];
  const zone = ZONES[zoneId];
  if (!zone) throw new Error("Unbekannte Zone: " + zoneId);
  const monsters = [];
  (zone.monsterSpawns || []).forEach(group => {
    const def = MONSTERS[group.monster];
    group.points.forEach(pt => {
      monsters.push({
        id: uid(), type: group.monster, x: pt.x, y: pt.y, homeX: pt.x, homeY: pt.y,
        hp: def.hp, maxHp: def.hp, state: "alive", respawnAt: 0, atkCd: 0, wanderT: Math.random() * 10, wDir: undefined
      });
    });
  });
  const resources = [];
  (zone.resourceSpawns || []).forEach(group => {
    group.points.forEach(pt => {
      resources.push({ id: uid(), item: group.item, kind: group.kind, x: pt.x, y: pt.y, readyAt: 0 });
    });
  });
  world[zoneId] = { monsters, resources, players: new Map(), bossSpawned: false };
  return world[zoneId];
}

const HARVEST_RANGE = 60;

/** Versucht, einen Rohstoffknoten zu ernten. Gibt {item} zurück oder wirft,
 *  wenn der Knoten nicht existiert, zu weit weg oder noch nicht bereit ist. */
function harvestResource(zoneId, resourceId, playerPos) {
  const state = ensureZone(zoneId);
  const res = state.resources.find(r => r.id === resourceId);
  if (!res) throw new Error("Rohstoff nicht gefunden");
  if (res.readyAt !== 0 && Date.now() < res.readyAt) throw new Error("Noch nicht nachgewachsen");
  if (playerPos && Math.hypot(playerPos.x - res.x, playerPos.y - res.y) > HARVEST_RANGE) {
    throw new Error("Zu weit weg");
  }
  res.readyAt = Date.now() + HARVEST_COOLDOWN_MS;
  return { item: res.item };
}

function respawnDelay(def) {
  if (def.boss) return BOSS_RESPAWN_MS;
  if (def.elite) return ELITE_RESPAWN_MS;
  return RESPAWN_MS;
}

/** Ein Welt-Tick für eine Zone: Monster-KI, Aggro, Angriffe auf nahe Spieler,
 *  Respawns. Gibt eine Liste von Ereignissen zurück, die der Aufrufer (server.js)
 *  an die Clients in der Zonen-Room broadcastet. */
function tickZone(zoneId, dt) {
  const state = ensureZone(zoneId);
  const zone = ZONES[zoneId];
  const now = Date.now();
  const events = [];

  state.resources.forEach(r => { if (r.readyAt && now > r.readyAt) r.readyAt = 0; });

  if (zone.bossArena && !state.bossSpawned) {
    for (const p of state.players.values()) {
      const d = Math.hypot(p.x - zone.bossArena.cx, p.y - zone.bossArena.cy);
      if (d < zone.bossArena.r) {
        const def = MONSTERS[zone.bossArena.boss];
        state.monsters.push({
          id: uid(), type: zone.bossArena.boss, x: zone.bossArena.cx, y: zone.bossArena.cy,
          homeX: zone.bossArena.cx, homeY: zone.bossArena.cy, hp: def.hp, maxHp: def.hp,
          state: "alive", respawnAt: 0, atkCd: 0, wanderT: 0
        });
        state.bossSpawned = true;
        events.push({ type: "boss:awakened", monster: zone.bossArena.boss });
        break;
      }
    }
  }

  const players = [...state.players.values()];
  state.monsters.forEach(m => {
    if (m.state === "dead") {
      if (now > m.respawnAt) {
        const def = MONSTERS[m.type];
        m.state = "alive"; m.hp = def.hp; m.maxHp = def.hp; m.x = m.homeX; m.y = m.homeY;
        events.push({ type: "monster:respawned", id: m.id, x: m.x, y: m.y, hp: m.hp });
      }
      return;
    }
    const def = MONSTERS[m.type];
    let nearest = null, nearestD = Infinity;
    for (const p of players) {
      const d = Math.hypot(p.x - m.x, p.y - m.y);
      if (d < nearestD) { nearestD = d; nearest = p; }
    }
    if (nearest && nearestD < AGGRO_RANGE && nearestD > MONSTER_ATTACK_RANGE) {
      const ang = Math.atan2(nearest.y - m.y, nearest.x - m.x);
      m.x += Math.cos(ang) * def.speed * (dt / 1000);
      m.y += Math.sin(ang) * def.speed * (dt / 1000);
    } else if (!nearest || nearestD >= AGGRO_RANGE) {
      m.wanderT -= dt / 1000;
      if (m.wanderT <= 0) { m.wanderT = 2 + Math.random() * 3; m.wDir = Math.random() * Math.PI * 2; }
      if (m.wDir !== undefined) {
        const nx = m.x + Math.cos(m.wDir) * def.speed * 0.3 * (dt / 1000);
        const ny = m.y + Math.sin(m.wDir) * def.speed * 0.3 * (dt / 1000);
        if (Math.hypot(nx - m.homeX, ny - m.homeY) < 60) { m.x = nx; m.y = ny; }
      }
    }
    if (nearest && nearestD < MONSTER_ATTACK_RANGE) {
      m.atkCd -= dt / 1000;
      if (m.atkCd <= 0) {
        m.atkCd = 1.3 + Math.random() * 0.4;
        events.push({ type: "monster:attack", monsterId: m.id, targetSocketId: nearest.socketId, atk: def.atk });
      }
    }
  });

  return events;
}

function joinZone(zoneId, socketId, playerState) {
  const state = ensureZone(zoneId);
  state.players.set(socketId, { socketId, ...playerState });
  return state;
}
function leaveZone(zoneId, socketId) {
  if (world[zoneId]) world[zoneId].players.delete(socketId);
}
function updatePlayerPos(zoneId, socketId, x, y, facing) {
  const state = world[zoneId];
  if (!state) return;
  const p = state.players.get(socketId);
  if (p) { p.x = x; p.y = y; p.facing = facing; }
}
function getMonster(zoneId, monsterId) {
  const state = world[zoneId];
  if (!state) return null;
  return state.monsters.find(m => m.id === monsterId) || null;
}
function killMonster(zoneId, monsterId) {
  const m = getMonster(zoneId, monsterId);
  if (!m) return null;
  const def = MONSTERS[m.type];
  m.state = "dead";
  m.respawnAt = Date.now() + respawnDelay(def);
  return m;
}
function zoneSnapshot(zoneId) {
  const state = ensureZone(zoneId);
  return {
    monsters: state.monsters.map(m => ({ id: m.id, type: m.type, x: m.x, y: m.y, hp: m.hp, maxHp: m.maxHp, state: m.state })),
    resources: state.resources.map(r => ({ id: r.id, item: r.item, kind: r.kind, x: r.x, y: r.y, ready: r.readyAt === 0 })),
    players: [...state.players.values()]
  };
}

module.exports = {
  ensureZone, tickZone, joinZone, leaveZone, updatePlayerPos, getMonster, killMonster,
  harvestResource, zoneSnapshot, world
};
