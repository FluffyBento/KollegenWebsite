"use strict";
require("dotenv").config();
const http = require("http");
const express = require("express");
const cors = require("cors");
const { Server } = require("socket.io");

const { socketAuthMiddleware, serviceAuthMiddleware } = require("./auth");
const { registerSocketHandlers } = require("./sockets");
const world = require("./world");
const combat = require("./combat");
const sessions = require("./sessions");
const { healthCheck } = require("./db");
const { ZONES } = require("./gameData");

const PORT = parseInt(process.env.PORT || "4000", 10);
const TICK_MS = 200; // 5 Ticks/Sekunde — reicht für ein top-down 2D-MMO dieser Art
const ACTIVE_ZONES = Object.keys(ZONES); // alle Zonen ticken; bei Bedarf später auf "Zonen mit Spielern" einschränken

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.ALLOWED_ORIGIN || "*" } });

io.use(socketAuthMiddleware);
io.on("connection", (socket) => registerSocketHandlers(io, socket));

/* ---------------------------------------------------------------------
 * Welt-Tick — Monster-KI/Respawns pro Zone, Ergebnisse an die jeweilige
 * Zonen-Room broadcasten
 * ------------------------------------------------------------------- */
let lastTick = Date.now();
setInterval(() => {
  const now = Date.now();
  const dt = now - lastTick;
  lastTick = now;
  for (const zoneId of ACTIVE_ZONES) {
    let events;
    try { events = world.tickZone(zoneId, dt); }
    catch (err) { console.error("[tick]", zoneId, err.message); continue; }
    if (!events.length) continue;
    for (const ev of events) {
      if (ev.type === "monster:attack") {
        const session = sessions.get(ev.targetSocketId);
        if (!session) continue;
        const spawn = (ZONES[session.character.zone] || ZONES.lobby).spawn;
        const result = combat.applyMonsterAttackToPlayer(session.character, ev.atk, spawn, session.phoenixState);
        io.to(ev.targetSocketId).emit("vitals:update", {
          hp: session.character.hp, x: session.character.x, y: session.character.y,
          downed: result.downed, phoenixSaved: result.phoenixSaved, dmg: result.dmg
        });
        if (result.downed) {
          world.updatePlayerPos(session.character.zone, ev.targetSocketId, session.character.x, session.character.y, 1);
          io.to(zoneId).emit("player:moved", { userId: session.character.websiteUserId, x: session.character.x, y: session.character.y, facing: 1 });
        }
      } else {
        io.to(zoneId).emit("world:event", ev);
      }
    }
  }
}, TICK_MS);

/* ---------------------------------------------------------------------
 * REST: Health-Check
 * ------------------------------------------------------------------- */
app.get("/health", async (req, res) => {
  let dbOk = false;
  try { dbOk = await healthCheck(); } catch (err) { dbOk = false; }
  res.json({ ok: dbOk, players: io.engine.clientsCount, uptime: process.uptime() });
});

/* ---------------------------------------------------------------------
 * REST: lokaler Mock des Website-Punkte-Endpunkts, nur damit
 * economy.exchangeLumenForPoints() ohne eure echte Website testbar ist.
 * In Produktion NICHT mounten — stattdessen WEBSITE_POINTS_URL setzen und
 * server.js auf den echten Endpunkt eurer Website zeigen lassen (siehe
 * README-server.md, Abschnitt "Punkte-Anbindung").
 * ------------------------------------------------------------------- */
if (process.env.MOCK_POINTS_ENDPOINT === "true") {
  app.post("/internal/api/points/credit", serviceAuthMiddleware, (req, res) => {
    console.log("[mock points api] würde gutschreiben:", req.body);
    res.json({ ok: true, mocked: true });
  });
}

server.listen(PORT, () => {
  console.log(`Elyndra-Server läuft auf Port ${PORT}`);
  console.log(`Health-Check: http://localhost:${PORT}/health`);
});
