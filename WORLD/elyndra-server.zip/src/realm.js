"use strict";
const { query, withTransaction } = require("./db");
const { ITEMS } = require("./gameData");

async function getRealmObjects(ownerId) {
  return query("SELECT grid_x AS gx, grid_y AS gy, item_id AS item FROM realm_objects WHERE owner_id=$1", [ownerId]);
}

/** Platziert/entfernt ein Objekt auf einem Gitterfeld im eigenen Reich.
 *  selectedItemId=null bedeutet "nur entfernen, falls dort etwas steht". */
async function buildAction(character, gx, gy, selectedItemId) {
  if (selectedItemId && (!ITEMS[selectedItemId] || !ITEMS[selectedItemId].placeable)) {
    throw new Error("Dieser Gegenstand ist nicht platzierbar");
  }
  return withTransaction(async (client) => {
    const existing = await client.query(
      "SELECT id, item_id FROM realm_objects WHERE owner_id=$1 AND grid_x=$2 AND grid_y=$3 FOR UPDATE",
      [character.id, gx, gy]
    );
    let removedItem = null;
    if (existing.rows[0]) {
      removedItem = existing.rows[0].item_id;
      await client.query("DELETE FROM realm_objects WHERE id=$1", [existing.rows[0].id]);
      const row = character.inventory.find(r => r.id === removedItem);
      const newQty = (row ? row.qty : 0) + 1;
      if (row) row.qty = newQty; else character.inventory.push({ id: removedItem, qty: newQty });
      await client.query(
        `INSERT INTO character_inventory (character_id, item_id, qty) VALUES ($1,$2,$3)
         ON CONFLICT (character_id, item_id) DO UPDATE SET qty=$3`,
        [character.id, removedItem, newQty]
      );
    }

    let placed = null;
    if (selectedItemId) {
      const row = character.inventory.find(r => r.id === selectedItemId);
      if (!row || row.qty < 1) throw new Error("Nicht genug Material");
      row.qty -= 1;
      await client.query(
        row.qty <= 0
          ? "DELETE FROM character_inventory WHERE character_id=$1 AND item_id=$2"
          : "UPDATE character_inventory SET qty=$3 WHERE character_id=$1 AND item_id=$2",
        row.qty <= 0 ? [character.id, selectedItemId] : [character.id, selectedItemId, row.qty]
      );
      if (row.qty <= 0) character.inventory = character.inventory.filter(r => r !== row);
      await client.query(
        "INSERT INTO realm_objects (owner_id, grid_x, grid_y, item_id) VALUES ($1,$2,$3,$4)",
        [character.id, gx, gy, selectedItemId]
      );
      placed = selectedItemId;
    }
    return { removedItem, placed };
  });
}

/** Für den Besuch: Reich per Charaktername finden (nur Lesezugriff). */
async function getRealmByName(name) {
  const res = await query("SELECT id, name FROM characters WHERE name=$1 LIMIT 1", [name]);
  const owner = res[0];
  if (!owner) return null;
  const objects = await getRealmObjects(owner.id);
  return { ownerId: owner.id, ownerName: owner.name, objects };
}

module.exports = { getRealmObjects, buildAction, getRealmByName };
