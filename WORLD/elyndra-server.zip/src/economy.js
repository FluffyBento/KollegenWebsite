"use strict";
const { query, withTransaction } = require("./db");
const { ITEMS, RECIPES, checkAchievements } = require("./gameData");
const characters = require("./characters");

/* ---------------------------------------------------------------------
 * Auktionshaus — echte DB-Transaktionen statt "letzter Schreibvorgang
 * gewinnt" wie im Browser-Prototyp. Ein Kauf kann nicht zweimal greifen.
 * ------------------------------------------------------------------- */
async function listAuctionItem(character, itemId, qty, price) {
  if (!ITEMS[itemId]) throw new Error("Unbekannter Gegenstand");
  if (qty <= 0 || price <= 0) throw new Error("Ungültige Menge oder Preis");
  const row = character.inventory.find(r => r.id === itemId);
  if (!row || row.qty < qty) throw new Error("Nicht genug im Inventar");

  return withTransaction(async (client) => {
    const newQty = row.qty - qty;
    if (newQty <= 0) await client.query("DELETE FROM character_inventory WHERE character_id=$1 AND item_id=$2", [character.id, itemId]);
    else await client.query("UPDATE character_inventory SET qty=$3 WHERE character_id=$1 AND item_id=$2", [character.id, itemId, newQty]);

    const ins = await client.query(
      `INSERT INTO auction_listings (seller_id, item_id, qty, price_lumen) VALUES ($1,$2,$3,$4) RETURNING id`,
      [character.id, itemId, qty, price]
    );
    row.qty = newQty;
    if (row.qty <= 0) character.inventory = character.inventory.filter(r => r !== row);
    return ins.rows[0].id;
  });
}

async function browseAuction() {
  return query(
    `SELECT al.id, al.item_id, al.qty, al.price_lumen, c.name AS seller_name, c.id AS seller_id
     FROM auction_listings al JOIN characters c ON c.id = al.seller_id
     WHERE al.sold_at IS NULL ORDER BY al.listed_at DESC LIMIT 200`
  );
}

async function buyAuctionItem(buyer, listingId) {
  return withTransaction(async (client) => {
    const res = await client.query("SELECT * FROM auction_listings WHERE id=$1 AND sold_at IS NULL FOR UPDATE", [listingId]);
    const listing = res.rows[0];
    if (!listing) throw new Error("Dieses Angebot ist nicht mehr verfügbar");
    if (listing.seller_id === buyer.id) throw new Error("Du kannst dein eigenes Angebot nicht kaufen");

    const buyerRow = await client.query("SELECT gold_lumen FROM characters WHERE id=$1 FOR UPDATE", [buyer.id]);
    if (buyerRow.rows[0].gold_lumen < listing.price_lumen) throw new Error("Nicht genug Lumen");

    await client.query("UPDATE characters SET gold_lumen = gold_lumen - $2 WHERE id=$1", [buyer.id, listing.price_lumen]);
    await client.query("UPDATE auction_listings SET sold_at=now(), buyer_id=$2 WHERE id=$1", [listingId, buyer.id]);

    const invRes = await client.query("SELECT qty FROM character_inventory WHERE character_id=$1 AND item_id=$2", [buyer.id, listing.item_id]);
    const newQty = (invRes.rows[0] ? invRes.rows[0].qty : 0) + listing.qty;
    await client.query(
      `INSERT INTO character_inventory (character_id, item_id, qty) VALUES ($1,$2,$3)
       ON CONFLICT (character_id, item_id) DO UPDATE SET qty=$3`,
      [buyer.id, listing.item_id, newQty]
    );

    // Verkäufer bekommt das Lumen ins Postfach, falls gerade nicht online
    await client.query(
      "INSERT INTO mailbox_entries (character_id, item_id, qty, amount_lumen) VALUES ($1,$2,$3,$4)",
      [listing.seller_id, listing.item_id, listing.qty, listing.price_lumen]
    );

    buyer.gold -= listing.price_lumen;
    const bRow = buyer.inventory.find(r => r.id === listing.item_id);
    if (bRow) bRow.qty = newQty; else buyer.inventory.push({ id: listing.item_id, qty: newQty });

    return { itemId: listing.item_id, qty: listing.qty, price: listing.price_lumen };
  });
}

async function cancelAuctionListing(character, listingId) {
  return withTransaction(async (client) => {
    const res = await client.query("SELECT * FROM auction_listings WHERE id=$1 AND sold_at IS NULL FOR UPDATE", [listingId]);
    const listing = res.rows[0];
    if (!listing) throw new Error("Angebot nicht gefunden");
    if (listing.seller_id !== character.id) throw new Error("Das ist nicht dein Angebot");
    await client.query("UPDATE auction_listings SET sold_at=now() WHERE id=$1", [listingId]); // sold_at ohne buyer_id = zurückgezogen

    const invRes = await client.query("SELECT qty FROM character_inventory WHERE character_id=$1 AND item_id=$2", [character.id, listing.item_id]);
    const newQty = (invRes.rows[0] ? invRes.rows[0].qty : 0) + listing.qty;
    await client.query(
      `INSERT INTO character_inventory (character_id, item_id, qty) VALUES ($1,$2,$3)
       ON CONFLICT (character_id, item_id) DO UPDATE SET qty=$3`,
      [character.id, listing.item_id, newQty]
    );
    const row = character.inventory.find(r => r.id === listing.item_id);
    if (row) row.qty = newQty; else character.inventory.push({ id: listing.item_id, qty: newQty });
    return { itemId: listing.item_id, qty: listing.qty };
  });
}

/* ---------------------------------------------------------------------
 * Postfach — Auszahlungen für Verkäufe, während man offline war
 * ------------------------------------------------------------------- */
async function claimMailbox(character) {
  const entries = await query(
    "SELECT * FROM mailbox_entries WHERE character_id=$1 AND claimed=false ORDER BY created_at",
    [character.id]
  );
  if (entries.length === 0) return [];
  await withTransaction(async (client) => {
    const total = entries.reduce((sum, e) => sum + e.amount_lumen, 0);
    await client.query("UPDATE characters SET gold_lumen = gold_lumen + $2 WHERE id=$1", [character.id, total]);
    await client.query("UPDATE mailbox_entries SET claimed=true WHERE character_id=$1 AND claimed=false", [character.id]);
  });
  character.gold += entries.reduce((sum, e) => sum + e.amount_lumen, 0);
  return entries;
}

/* ---------------------------------------------------------------------
 * Lumen ↔ Website-Punkte. webhookFn(userId, points, idempotencyKey) muss
 * ein Promise<{ok:boolean}> liefern — siehe server.js für die Anbindung an
 * eure bestehende Website bzw. den lokalen Mock-Endpunkt zum Testen.
 * ------------------------------------------------------------------- */
const EXCHANGE_RATE = 10; // Lumen pro Punkt

async function exchangeLumenForPoints(character, amount, webhookFn) {
  const points = Math.floor(amount / EXCHANGE_RATE);
  if (points <= 0) throw new Error("Betrag zu gering (mindestens " + EXCHANGE_RATE + " Lumen)");
  const spend = points * EXCHANGE_RATE;
  if (character.gold < spend) throw new Error("Nicht genug Lumen");

  const idempotencyKey = character.id + "-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);

  await withTransaction(async (client) => {
    const row = await client.query("SELECT gold_lumen FROM characters WHERE id=$1 FOR UPDATE", [character.id]);
    if (row.rows[0].gold_lumen < spend) throw new Error("Nicht genug Lumen");
    await client.query("UPDATE characters SET gold_lumen = gold_lumen - $2 WHERE id=$1", [character.id, spend]);
    await client.query(
      "INSERT INTO lumen_transactions (character_id, amount, reason, idempotency_key) VALUES ($1,$2,'points_exchange',$3)",
      [character.id, -spend, idempotencyKey]
    );
  });
  character.gold -= spend;

  try {
    const result = await webhookFn(character.websiteUserId, points, idempotencyKey);
    if (!result || !result.ok) throw new Error("Punkte-API hat den Umtausch abgelehnt");
    return { points, spend };
  } catch (err) {
    // Rollback: Lumen zurückbuchen, da die Website die Punkte nicht gutschreiben konnte
    await withTransaction(async (client) => {
      await client.query("UPDATE characters SET gold_lumen = gold_lumen + $2 WHERE id=$1", [character.id, spend]);
      await client.query(
        "INSERT INTO lumen_transactions (character_id, amount, reason) VALUES ($1,$2,'points_exchange_rollback')",
        [character.id, spend]
      );
    });
    character.gold += spend;
    throw new Error("Umtausch fehlgeschlagen, Lumen wurde zurückerstattet: " + err.message);
  }
}

/* ---------------------------------------------------------------------
 * Herstellung
 * ------------------------------------------------------------------- */
async function craftItem(character, recipeId) {
  const recipe = RECIPES.find(r => r.id === recipeId);
  if (!recipe) throw new Error("Unbekanntes Rezept");
  if (character.level < recipe.level) throw new Error("Level " + recipe.level + " erforderlich");
  for (const [matId, qty] of recipe.mats) {
    const row = character.inventory.find(r => r.id === matId);
    if (!row || row.qty < qty) throw new Error("Nicht genug " + (ITEMS[matId] ? ITEMS[matId].name : matId));
  }
  for (const [matId, qty] of recipe.mats) {
    const row = character.inventory.find(r => r.id === matId);
    row.qty -= qty;
    await characters.setInventoryQty(character.id, matId, row.qty);
    if (row.qty <= 0) character.inventory = character.inventory.filter(r => r !== row);
  }
  const resultRow = character.inventory.find(r => r.id === recipe.result);
  const newQty = (resultRow ? resultRow.qty : 0) + recipe.qty;
  if (resultRow) resultRow.qty = newQty; else character.inventory.push({ id: recipe.result, qty: newQty });
  await characters.setInventoryQty(character.id, recipe.result, newQty);

  character.counters.crafts++;
  const unlocked = checkAchievements(character);
  for (const a of unlocked) await characters.grantAchievement(character.id, a.id);
  return { result: recipe.result, qty: recipe.qty, achievements: unlocked.map(a => a.id) };
}

module.exports = {
  listAuctionItem, browseAuction, buyAuctionItem, cancelAuctionListing,
  claimMailbox, exchangeLumenForPoints, craftItem, EXCHANGE_RATE
};
