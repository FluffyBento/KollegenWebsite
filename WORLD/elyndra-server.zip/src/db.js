"use strict";
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: parseInt(process.env.DB_POOL_SIZE || "10", 10)
});

pool.on("error", (err) => {
  console.error("[db] Unerwarteter Fehler auf einem Idle-Client:", err.message);
});

/** Einfache Query, gibt rows zurück. */
async function query(text, params) {
  const res = await pool.query(text, params);
  return res.rows;
}

/** Führt fn innerhalb einer Transaktion aus. fn erhält einen Client mit .query(). */
async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

async function healthCheck() {
  await pool.query("SELECT 1");
  return true;
}

module.exports = { pool, query, withTransaction, healthCheck };
