"use strict";
const { ITEMS, SHOPS, ZONES, BOUNTIES, findSkillNode, checkAchievements } = require("./gameData");
const { computeStats } = require("./stats");
const characters = require("./characters");
const world = require("./world");
const combat = require("./combat");
const economy = require("./economy");
const realm = require("./realm");
const sessions = require("./sessions");
const { callPointsWebhook } = require("./pointsWebhook");

const MOVE_MAX_SPEED = 260; // px/s — großzügige Obergrenze über dem regulären Tempo (150-190 mit Buffs), reines Anti-Cheat-Grobraster
const SAVE_INTERVAL_MS = 8000;

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/** try/catch-Wrapper für ack-basierte Events, damit Fehler als {ok:false,error}
 *  beim Client ankommen statt den Server-Prozess zu crashen. */
function safeAck(fn) {
  return async (payload, ack) => {
    const respond = typeof ack === "function" ? ack : () => {};
    try {
      const result = await fn(payload);
      respond({ ok: true, ...result });
    } catch (err) {
      respond({ ok: false, error: err.message });
    }
  };
}

function publicPlayerState(character) {
  return { userId: character.websiteUserId, name: character.name, color: character.color, x: character.x, y: character.y, facing: 1, level: character.level };
}

function registerSocketHandlers(io, socket) {
  const { userId, username } = socket.user;
  let character = null;
  let currentZone = null;
  let lastMoveAt = 0;
  const phoenixState = { ready: true };
  let saveTimer = null;

  function scheduleSave() {
    if (saveTimer) return;
    saveTimer = setTimeout(async () => {
      saveTimer = null;
      if (character) {
        try { await characters.saveCharacterCore(character); }
        catch (err) { console.error("[save]", username, err.message); }
      }
    }, SAVE_INTERVAL_MS);
  }

  async function joinZone(zoneId, spawn) {
    const zoneDef = ZONES[zoneId];
    if (!zoneDef) throw new Error("Unbekannte Zone");
    if (currentZone) {
      world.leaveZone(currentZone, socket.id);
      socket.leave(currentZone);
      socket.to(currentZone).emit("player:left", { userId });
    }
    currentZone = zoneId;
    character.zone = zoneId;
    character.x = spawn.x; character.y = spawn.y;
    socket.join(zoneId);
    world.joinZone(zoneId, socket.id, { x: character.x, y: character.y, facing: 1, userId, name: character.name });

    const isBiome = zoneDef.type === "town" || zoneDef.type === "wild" || zoneDef.type === "dungeon";
    if (isBiome && !character.discovered.includes(zoneId)) {
      character.discovered.push(zoneId);
      await characters.discoverZone(character.id, zoneId);
      const unlocked = checkAchievements(character);
      for (const a of unlocked) await characters.grantAchievement(character.id, a.id);
      if (unlocked.length) socket.emit("achievements:unlocked", unlocked.map(a => a.id));
      socket.emit("zone:discovered", { zoneId, name: zoneDef.name });
    }

    socket.emit("zone:state", { zone: zoneId, ...world.zoneSnapshot(zoneId), character: sanitizedCharacter() });
    socket.to(zoneId).emit("player:joined", { userId, ...publicPlayerState(character) });
    scheduleSave();
  }

  function sanitizedCharacter() {
    // schickt dem eigenen Client den vollen, autoritativen Zustand (Inventar, Stats, etc.)
    const stats = computeStats(character);
    return { ...character, stats };
  }

  const NEEDS_TICK_MS = 1000;
  function tickNeeds() {
    if (!character) return;
    const stats = computeStats(character);
    const rate = (100 / 900) * stats.needMult; // Prozentpunkte pro Sekunde, Intervall ist 1s
    character.hunger = clamp(character.hunger - rate, 0, 100);
    character.thirst = clamp(character.thirst - rate, 0, 100);

    if ((character.hunger <= 0 || character.thirst <= 0) && !stats.needImmune) {
      const drain = (character.hunger <= 0 && character.thirst <= 0) ? 1.6 : 0.8;
      character.hp = clamp(character.hp - drain, 0, stats.maxHP);
    } else if (character.hunger > 0 && character.thirst > 0) {
      character.hp = clamp(character.hp + 0.6, 0, stats.maxHP);
    }
    character.mp = clamp((character.mp || 0) + 1.1 * stats.mpRegenMult, 0, stats.maxMP);
    character.stamina = clamp((character.stamina || 0) + 9, 0, stats.maxStamina);
    if (character.hp >= stats.maxHP) phoenixState.ready = true;

    let downed = false, phoenixSaved = false;
    if (character.hp <= 0) {
      if (stats.phoenix && phoenixState.ready) {
        character.hp = 1; phoenixState.ready = false; phoenixSaved = true;
      } else {
        const spawn = (ZONES[character.zone] || ZONES.lobby).spawn;
        character.hp = Math.round(stats.maxHP * 0.5);
        character.x = spawn.x; character.y = spawn.y;
        world.updatePlayerPos(character.zone, socket.id, character.x, character.y, 1);
        downed = true;
      }
    }

    socket.emit("vitals:update", {
      hp: character.hp, mp: character.mp, stamina: character.stamina,
      hunger: character.hunger, thirst: character.thirst,
      maxHP: stats.maxHP, maxMP: stats.maxMP, maxStamina: stats.maxStamina,
      x: character.x, y: character.y, downed, phoenixSaved
    });
    scheduleSave();
  }
  const needsInterval = setInterval(tickNeeds, NEEDS_TICK_MS);

  (async () => {
    try {
      character = await characters.loadOrCreateCharacter(userId, username);
      console.log(`[connect] ${username} (${character.name}) -> ${character.zone}`);
      sessions.register(socket.id, { character, phoenixState });
      await joinZone(character.zone, { x: character.x, y: character.y });
      const mailboxEntries = await economy.claimMailbox(character);
      if (mailboxEntries.length) socket.emit("mailbox:claimed", mailboxEntries);
    } catch (err) {
      console.error("[connect] Fehler beim Laden des Charakters:", err.message);
      socket.emit("fatal:error", { error: "Charakter konnte nicht geladen werden" });
      socket.disconnect(true);
    }
  })();

  /* ---- Bewegung ---- */
  socket.on("player:move", ({ x, y, facing }) => {
    if (!character || typeof x !== "number" || typeof y !== "number") return;
    const now = Date.now();
    const dt = Math.max(0.001, (now - (lastMoveAt || now)) / 1000);
    const dist = Math.hypot(x - character.x, y - character.y);
    if (dist / dt > MOVE_MAX_SPEED * 1.5) return; // grobe Anti-Cheat-Schwelle, verwirft unplausible Sprünge
    lastMoveAt = now;
    const zoneDef = ZONES[currentZone];
    character.x = clamp(x, 0, zoneDef.w);
    character.y = clamp(y, 0, zoneDef.h);
    world.updatePlayerPos(currentZone, socket.id, character.x, character.y, facing);
    socket.to(currentZone).emit("player:moved", { userId, x: character.x, y: character.y, facing });
  });

  /* ---- Zonenwechsel ---- */
  socket.on("zone:change", safeAck(async ({ targetZone, spawn }) => {
    const zoneDef = ZONES[targetZone];
    if (!zoneDef) throw new Error("Unbekannte Zone");
    if (zoneDef.minLevel && character.level < zoneDef.minLevel) {
      // kein hartes Verbot (passt zum Client-Prototyp), aber der Server könnte hier
      // je nach Design auch strikt ablehnen — bewusst als Warnung gehalten
    }
    await joinZone(targetZone, spawn || zoneDef.spawn);
    return { zone: targetZone };
  }));

  /* ---- Kampf ---- */
  socket.on("combat:attack", safeAck(async () => {
    const result = await combat.resolveAttack(character, currentZone);
    if (result.hits.length) io.to(currentZone).emit("combat:hits", { attackerUserId: userId, hits: result.hits });
    scheduleSave();
    return result;
  }));

  socket.on("combat:useSkill", safeAck(async ({ skillId }) => {
    const result = await combat.resolveSkillUse(character, currentZone, skillId);
    if (!result.ok) throw new Error(result.error);
    if (result.hits && result.hits.length) io.to(currentZone).emit("combat:hits", { attackerUserId: userId, hits: result.hits });
    scheduleSave();
    return result;
  }));

  /* ---- Sammeln ---- */
  socket.on("gather:harvest", safeAck(async ({ resourceId }) => {
    const stats = computeStats(character);
    const { item } = world.harvestResource(currentZone, resourceId, { x: character.x, y: character.y });
    const qty = Math.max(1, Math.round((1 + Math.floor(Math.random() * 2)) * stats.gatherMult));
    const row = character.inventory.find(r => r.id === item);
    const newQty = (row ? row.qty : 0) + qty;
    if (row) row.qty = newQty; else character.inventory.push({ id: item, qty: newQty });
    await characters.setInventoryQty(character.id, item, newQty);
    character.counters.gathers += qty;
    combat.bumpBounty(character, "gather", null, qty);
    const unlocked = checkAchievements(character);
    for (const a of unlocked) await characters.grantAchievement(character.id, a.id);
    scheduleSave();
    return { item, qty, achievements: unlocked.map(a => a.id) };
  }));

  /* ---- Inventar / Ausrüstung ---- */
  socket.on("inventory:equip", safeAck(async ({ slot, itemId }) => {
    if (!["weapon", "armor", "accessory"].includes(slot)) throw new Error("Ungültiger Slot");
    const it = ITEMS[itemId];
    if (!it || it.type !== slot) throw new Error("Gegenstand passt nicht in diesen Slot");
    if (!(character.inventory.find(r => r.id === itemId && r.qty > 0))) throw new Error("Nicht im Inventar");
    character.equipment[slot] = itemId;
    scheduleSave();
    return { equipment: character.equipment };
  }));
  socket.on("inventory:unequip", safeAck(async ({ slot }) => {
    character.equipment[slot] = null;
    scheduleSave();
    return { equipment: character.equipment };
  }));
  socket.on("inventory:useConsumable", safeAck(async ({ itemId }) => {
    const it = ITEMS[itemId];
    if (!it || it.type !== "consumable") throw new Error("Kein Verbrauchsgegenstand");
    const row = character.inventory.find(r => r.id === itemId);
    if (!row || row.qty < 1) throw new Error("Nicht im Inventar");
    const stats = computeStats(character);
    if (it.heal) character.hp = clamp(character.hp + it.heal, 0, stats.maxHP);
    if (it.hunger) character.hunger = clamp(character.hunger + it.hunger, 0, 100);
    if (it.thirst) character.thirst = clamp(character.thirst + it.thirst, 0, 100);
    if (it.mana) character.mp = clamp((character.mp || 0) + it.mana, 0, stats.maxMP);
    if (it.stamina) character.stamina = clamp((character.stamina || 0) + it.stamina, 0, stats.maxStamina);
    if (it.buffStat) {
      character.buffs = (character.buffs || []).filter(b => b.stat !== it.buffStat);
      character.buffs.push({ stat: it.buffStat, mult: it.buffMult, until: Date.now() + it.buffDuration * 1000 });
    }
    row.qty -= 1;
    await characters.setInventoryQty(character.id, itemId, row.qty);
    if (row.qty <= 0) character.inventory = character.inventory.filter(r => r !== row);
    scheduleSave();
    return { hp: character.hp, hunger: character.hunger, thirst: character.thirst };
  }));
  socket.on("character:allocateAttr", safeAck(async ({ attr, delta }) => {
    const valid = ["leben", "verteidigung", "magie", "angriff", "ausdauer"];
    if (!valid.includes(attr) || (delta !== 1 && delta !== -1)) throw new Error("Ungültig");
    if (delta > 0 && character.attr_points <= 0) throw new Error("Keine Punkte übrig");
    if (delta < 0 && character.attrs[attr] <= 0) throw new Error("Nichts zum Zurücknehmen");
    character.attrs[attr] += delta;
    character.attr_points -= delta;
    scheduleSave();
    return { attrs: character.attrs, attr_points: character.attr_points };
  }));

  /* ---- Fähigkeitsbäume ---- */
  socket.on("skills:unlock", safeAck(async ({ skillId }) => {
    const node = findSkillNode(skillId);
    if (!node) throw new Error("Unbekannte Fähigkeit");
    if (character.unlocked_skills.includes(skillId)) throw new Error("Bereits freigeschaltet");
    if (node.requires && !character.unlocked_skills.includes(node.requires)) throw new Error("Voraussetzung fehlt");
    if (node.need && !character.achievements.includes(node.need)) throw new Error("Errungenschaft fehlt: " + node.need);
    if (character.skill_points < node.cost) throw new Error("Nicht genug Fähigkeitspunkte");
    character.skill_points -= node.cost;
    character.unlocked_skills.push(skillId);
    await characters.unlockSkill(character.id, skillId);
    if (node.type === "active") {
      const freeSlot = character.hotbar.indexOf(null);
      if (freeSlot !== -1) character.hotbar[freeSlot] = skillId;
    }
    scheduleSave();
    return { skill_points: character.skill_points, unlocked_skills: character.unlocked_skills, hotbar: character.hotbar };
  }));
  socket.on("skills:assignHotbar", safeAck(async ({ slot, skillId }) => {
    if (slot < 0 || slot > 3) throw new Error("Ungültiger Slot");
    if (skillId && !character.unlocked_skills.includes(skillId)) throw new Error("Nicht freigeschaltet");
    character.hotbar[slot] = skillId || null;
    scheduleSave();
    return { hotbar: character.hotbar };
  }));

  /* ---- Herstellung ---- */
  socket.on("craft:make", safeAck(async ({ recipeId }) => {
    const result = await economy.craftItem(character, recipeId);
    scheduleSave();
    return result;
  }));

  /* ---- Handel mit NPCs ---- */
  socket.on("shop:buy", safeAck(async ({ shopId, itemId }) => {
    const shop = SHOPS[shopId];
    if (!shop || !shop.sells.includes(itemId)) throw new Error("Nicht im Sortiment");
    const it = ITEMS[itemId];
    if (!it.buy) throw new Error("Nicht käuflich");
    if (character.gold < it.buy) throw new Error("Nicht genug Lumen");
    character.gold -= it.buy;
    const row = character.inventory.find(r => r.id === itemId);
    const newQty = (row ? row.qty : 0) + 1;
    if (row) row.qty = newQty; else character.inventory.push({ id: itemId, qty: newQty });
    await characters.setInventoryQty(character.id, itemId, newQty);
    scheduleSave();
    return { gold: character.gold, itemId, qty: newQty };
  }));
  socket.on("shop:sell", safeAck(async ({ itemId, qty }) => {
    qty = Math.max(1, qty | 0);
    const it = ITEMS[itemId];
    if (!it || !it.sell) throw new Error("Nicht verkäuflich");
    const row = character.inventory.find(r => r.id === itemId);
    if (!row || row.qty < qty) throw new Error("Nicht genug im Inventar");
    row.qty -= qty;
    character.gold += it.sell * qty;
    await characters.setInventoryQty(character.id, itemId, row.qty);
    if (row.qty <= 0) character.inventory = character.inventory.filter(r => r !== row);
    scheduleSave();
    return { gold: character.gold, itemId, remaining: row.qty };
  }));

  /* ---- Auktionshaus ---- */
  socket.on("auction:browse", safeAck(async () => ({ listings: await economy.browseAuction() })));
  socket.on("auction:list", safeAck(async ({ itemId, qty, price }) => {
    const id = await economy.listAuctionItem(character, itemId, qty, price);
    scheduleSave();
    return { listingId: id };
  }));
  socket.on("auction:buy", safeAck(async ({ listingId }) => {
    const result = await economy.buyAuctionItem(character, listingId);
    scheduleSave();
    return result;
  }));
  socket.on("auction:cancel", safeAck(async ({ listingId }) => {
    const result = await economy.cancelAuctionListing(character, listingId);
    scheduleSave();
    return result;
  }));

  /* ---- Tägliche Aufträge & Tageskiste ---- */
  socket.on("bounty:claim", safeAck(async ({ bountyId }) => {
    const b = BOUNTIES.find(x => x.id === bountyId);
    if (!b) throw new Error("Unbekannter Auftrag");
    const st = character.daily.bounties[bountyId];
    if (!st || st.progress < b.count || st.claimed) throw new Error("Noch nicht abschließbar");
    st.claimed = true;
    character.gold += b.gold;
    combat.grantXP(character, b.xp);
    scheduleSave();
    return { gold: character.gold, xp: character.xp, level: character.level };
  }));
  socket.on("dailychest:open", safeAck(async () => {
    if (character.daily.chestClaimed) throw new Error("Schon geöffnet heute — komm morgen wieder");
    character.daily.chestClaimed = true;
    const goldReward = 10 + Math.floor(Math.random() * 16);
    const matPool = ["holz", "kraeuter", "erz"];
    const mat = matPool[Math.floor(Math.random() * matPool.length)];
    const matQty = 2 + Math.floor(Math.random() * 3);
    character.gold += goldReward;
    const row = character.inventory.find(r => r.id === mat);
    const newQty = (row ? row.qty : 0) + matQty;
    if (row) row.qty = newQty; else character.inventory.push({ id: mat, qty: newQty });
    await characters.setInventoryQty(character.id, mat, newQty);
    scheduleSave();
    return { gold: goldReward, item: mat, qty: matQty };
  }));

  /* ---- Reich ---- */
  socket.on("realm:build", safeAck(async ({ gx, gy, itemId }) => {
    const result = await realm.buildAction(character, gx, gy, itemId || null);
    io.to("realm:" + character.id).emit("realm:updated", { gx, gy, itemId: result.placed });
    scheduleSave();
    return result;
  }));
  socket.on("realm:visit", safeAck(async ({ name }) => {
    const found = await realm.getRealmByName(name);
    if (!found) throw new Error("Kein Reich mit diesem Namen gefunden");
    socket.join("realm:" + found.ownerId); // für Live-Updates, während man zu Besuch ist
    return found;
  }));
  socket.on("realm:leaveVisit", safeAck(async ({ ownerId }) => {
    socket.leave("realm:" + ownerId);
    return {};
  }));

  /* ---- Chat ---- */
  socket.on("chat:message", (text) => {
    if (!character || !currentZone) return;
    const clean = String(text || "").slice(0, 200);
    if (!clean.trim()) return;
    io.to(currentZone).emit("chat:message", { from: character.name, text: clean, ts: Date.now() });
  });

  /* ---- Postfach manuell abrufen (zusätzlich zum Auto-Check beim Verbinden) ---- */
  socket.on("mailbox:claim", safeAck(async () => ({ entries: await economy.claimMailbox(character) })));

  /* ---- Lumen ↔ Website-Punkte ---- */
  socket.on("economy:exchangeLumen", safeAck(async ({ amount }) => {
    const result = await economy.exchangeLumenForPoints(character, amount, callPointsWebhook);
    scheduleSave();
    return result;
  }));

  /* ---- Trennung ---- */
  socket.on("disconnect", async () => {
    console.log(`[disconnect] ${username}`);
    clearInterval(needsInterval);
    sessions.unregister(socket.id);
    if (currentZone) {
      world.leaveZone(currentZone, socket.id);
      socket.to(currentZone).emit("player:left", { userId });
    }
    if (character) {
      try { await characters.saveCharacterCore(character); }
      catch (err) { console.error("[disconnect save]", username, err.message); }
    }
  });
}

module.exports = { registerSocketHandlers };
