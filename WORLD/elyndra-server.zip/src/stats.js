"use strict";
const { ITEMS, findSkillNode } = require("./gameData");

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/**
 * Serverseitige Entsprechung von computeStats() im Client. Nimmt einen
 * Charakter-Datensatz (siehe characters.js) inkl. geladener unlocked_skills
 * entgegen und liefert die tatsächlich wirksamen Kampfwerte. Das ist die
 * einzige Stelle, die für Schadensberechnung herangezogen werden darf —
 * niemals Werte vom Client übernehmen (Anti-Cheat).
 */
function computeStats(character) {
  const a = character.attrs;
  let maxHP = 80 + character.level * 4 + a.leben * 8;
  let maxMP = 20 + character.level * 1 + a.magie * 3;
  let maxStamina = 80 + character.level * 2 + a.ausdauer * 6;
  let atk = 4 + character.level * 1 + a.angriff * 1;
  let def = 1 + a.verteidigung * 1;
  let mag = 1 + a.magie * 1;
  let speed = 150;
  let cdMult = 1, needMult = 1, gatherMult = 1, gatherSpeedMult = 1, lootMult = 1,
      mpRegenMult = 1, hpMult = 1, speedMult = 1, needImmune = false, darkDefBonus = 0,
      phoenix = false, critBonus = 0.05;

  const w = character.equipment.weapon && ITEMS[character.equipment.weapon];
  const ar = character.equipment.armor && ITEMS[character.equipment.armor];
  const ac = character.equipment.accessory && ITEMS[character.equipment.accessory];
  if (w) { atk += w.atk || 0; mag += w.mag || 0; critBonus += w.crit || 0; }
  if (ar) { def += ar.def || 0; maxHP += ar.hp || 0; }
  if (ac) { mag += ac.mag || 0; maxMP += ac.mp || 0; atk += ac.atk || 0; def += ac.def || 0; maxHP += ac.hp || 0; }

  for (const skillId of character.unlocked_skills || []) {
    const node = findSkillNode(skillId);
    if (!node || node.type !== "passive") continue;
    const e = node.effect || {};
    if (e.atkMult) atk *= e.atkMult;
    if (e.hpMult) hpMult *= e.hpMult;
    if (e.mpRegenMult) mpRegenMult *= e.mpRegenMult;
    if (e.cdMult) cdMult *= e.cdMult;
    if (e.needMult) needMult *= e.needMult;
    if (e.gatherMult) gatherMult *= e.gatherMult;
    if (e.gatherSpeedMult) gatherSpeedMult *= e.gatherSpeedMult;
    if (e.lootMult) lootMult *= e.lootMult;
    if (e.speedMult) speedMult *= e.speedMult;
    if (e.defBonus) darkDefBonus += e.defBonus;
    if (e.needImmune) needImmune = true;
    if (e.phoenix) phoenix = true;
    if (e.critBonus) critBonus += e.critBonus;
  }

  if (character.buffs && character.buffs.length) {
    const now = Date.now();
    character.buffs = character.buffs.filter(b => b.until > now);
    character.buffs.forEach(b => {
      if (b.stat === "atk") atk *= b.mult;
      else if (b.stat === "mag") mag *= b.mult;
      else if (b.stat === "def") def *= b.mult;
    });
  }

  maxHP = Math.round(maxHP * hpMult);
  speed *= speedMult;
  return {
    maxHP, maxMP: Math.round(maxMP), maxStamina: Math.round(maxStamina),
    atk: Math.round(atk), def: Math.round(def), mag: Math.round(mag), speed,
    cdMult, needMult, gatherMult, gatherSpeedMult, lootMult, mpRegenMult,
    needImmune, darkDefBonus, phoenix, critBonus
  };
}

function xpNeed(level) { return Math.round(30 + level * 22); }

module.exports = { computeStats, xpNeed, clamp };
