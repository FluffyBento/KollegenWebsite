"use strict";
const { query, withTransaction } = require("./db");

const NEW_CHAR_DEFAULTS = {
  inventory: [
    { item_id: "holzschwert", qty: 1 },
    { item_id: "apfel", qty: 3 },
    { item_id: "wasserflasche", qty: 3 },
    { item_id: "heiltrank", qty: 1 }
  ]
};

function todayDateStr() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

/** Baut das verschachtelte Charakterobjekt (wie computeStats/gameData es erwarten)
 *  aus der flachen DB-Zeile + den zugehörigen Nebentabellen zusammen. */
function assemble(row, unlockedSkills, achievements, discoveredZones, inventoryRows) {
  return {
    id: row.id,
    websiteUserId: row.website_user_id,
    name: row.name,
    color: row.color,
    level: row.level,
    xp: row.xp,
    attrs: {
      leben: row.attr_leben, verteidigung: row.attr_verteidigung, magie: row.attr_magie,
      angriff: row.attr_angriff, ausdauer: row.attr_ausdauer
    },
    attr_points: row.attr_points,
    skill_points: row.skill_points,
    gold: row.gold_lumen,
    hunger: row.hunger, thirst: row.thirst, hp: row.hp, mp: row.mp, stamina: row.stamina,
    zone: row.zone_id, x: row.pos_x, y: row.pos_y,
    equipment: { weapon: row.equipped_weapon, armor: row.equipped_armor, accessory: row.equipped_accessory },
    hotbar: row.hotbar,
    flags: row.flags || {},
    buffs: row.buffs || [],
    counters: { kills: row.counter_kills, crafts: row.counter_crafts, gathers: row.counter_gathers, elites: row.counter_elites },
    daily: {
      date: row.daily_date instanceof Date ? row.daily_date.toISOString().slice(0, 10) : row.daily_date,
      bounties: row.daily_bounties || {},
      chestClaimed: row.daily_chest_claimed
    },
    unlocked_skills: unlockedSkills,
    achievements,
    discovered: discoveredZones,
    inventory: inventoryRows.map(r => ({ id: r.item_id, qty: r.qty }))
  };
}

async function loadRelated(client, characterId) {
  const [skills, achievements, zones, inventory] = await Promise.all([
    client.query("SELECT skill_id FROM character_unlocked_skills WHERE character_id=$1", [characterId]),
    client.query("SELECT achievement_id FROM character_achievements WHERE character_id=$1", [characterId]),
    client.query("SELECT zone_id FROM character_discovered_zones WHERE character_id=$1", [characterId]),
    client.query("SELECT item_id, qty FROM character_inventory WHERE character_id=$1", [characterId])
  ]);
  return {
    unlockedSkills: skills.rows.map(r => r.skill_id),
    achievements: achievements.rows.map(r => r.achievement_id),
    discoveredZones: zones.rows.map(r => r.zone_id),
    inventory: inventory.rows
  };
}

/** Lädt den Charakter zu einem Website-Account, legt bei Bedarf einen neuen an
 *  (Level 1, Startausrüstung) — es gibt keinen separaten Elyndra-Account. */
async function loadOrCreateCharacter(websiteUserId, username) {
  return withTransaction(async (client) => {
    let res = await client.query("SELECT * FROM characters WHERE website_user_id=$1 FOR UPDATE", [websiteUserId]);
    let row = res.rows[0];

    if (!row) {
      const insert = await client.query(
        `INSERT INTO characters (website_user_id, name) VALUES ($1, $2) RETURNING *`,
        [websiteUserId, username || "Abenteurer"]
      );
      row = insert.rows[0];
      for (const item of NEW_CHAR_DEFAULTS.inventory) {
        await client.query(
          "INSERT INTO character_inventory (character_id, item_id, qty) VALUES ($1,$2,$3)",
          [row.id, item.item_id, item.qty]
        );
      }
      await client.query(
        "INSERT INTO character_discovered_zones (character_id, zone_id) VALUES ($1,'lobby')",
        [row.id]
      );
    }

    // täglicher Reset (Aufträge/Tageskiste), falls seit dem letzten Login ein neuer Tag begonnen hat
    const today = todayDateStr();
    if (row.daily_date === null || String(row.daily_date).slice(0, 10) !== today) {
      const upd = await client.query(
        `UPDATE characters SET daily_date=$2, daily_bounties='{}', daily_chest_claimed=false, updated_at=now()
         WHERE id=$1 RETURNING *`,
        [row.id, today]
      );
      row = upd.rows[0];
    }

    const related = await loadRelated(client, row.id);
    return assemble(row, related.unlockedSkills, related.achievements, related.discoveredZones, related.inventory);
  });
}

/** Schreibt die veränderlichen Felder eines Charakters zurück (Position, Stats,
 *  Bedürfnisse, Gold, Flags/Buffs/Tagesfortschritt). Inventar/Skills/Achievements/
 *  entdeckte Zonen laufen über eigene, gezielte Funktionen (siehe unten), damit
 *  nicht bei jedem Bewegungs-Tick das ganze Inventar mitgeschrieben wird. */
async function saveCharacterCore(character) {
  await query(
    `UPDATE characters SET
       level=$2, xp=$3, attr_leben=$4, attr_verteidigung=$5, attr_magie=$6, attr_angriff=$7, attr_ausdauer=$8,
       attr_points=$9, skill_points=$10, gold_lumen=$11, hunger=$12, thirst=$13, hp=$14, mp=$15, stamina=$16,
       zone_id=$17, pos_x=$18, pos_y=$19,
       equipped_weapon=$20, equipped_armor=$21, equipped_accessory=$22, hotbar=$23,
       flags=$24, buffs=$25,
       counter_kills=$26, counter_crafts=$27, counter_gathers=$28, counter_elites=$29,
       daily_bounties=$30, daily_chest_claimed=$31,
       updated_at=now()
     WHERE id=$1`,
    [
      character.id, character.level, character.xp,
      character.attrs.leben, character.attrs.verteidigung, character.attrs.magie, character.attrs.angriff, character.attrs.ausdauer,
      character.attr_points, character.skill_points, character.gold, character.hunger, character.thirst,
      character.hp, character.mp, character.stamina,
      character.zone, character.x, character.y,
      character.equipment.weapon, character.equipment.armor, character.equipment.accessory, JSON.stringify(character.hotbar),
      JSON.stringify(character.flags), JSON.stringify(character.buffs),
      character.counters.kills, character.counters.crafts, character.counters.gathers, character.counters.elites,
      JSON.stringify(character.daily.bounties), character.daily.chestClaimed
    ]
  );
}

async function unlockSkill(characterId, skillId) {
  await query(
    "INSERT INTO character_unlocked_skills (character_id, skill_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [characterId, skillId]
  );
}
async function grantAchievement(characterId, achievementId) {
  await query(
    "INSERT INTO character_achievements (character_id, achievement_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [characterId, achievementId]
  );
}
async function discoverZone(characterId, zoneId) {
  await query(
    "INSERT INTO character_discovered_zones (character_id, zone_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [characterId, zoneId]
  );
}

/** Setzt die Menge eines Items im Inventar (0 löscht die Zeile). Atomar genug
 *  für unsere Zwecke, solange Inventaränderungen pro Charakter seriell über
 *  dieselbe Socket-Verbindung laufen (siehe sockets.js). */
async function setInventoryQty(characterId, itemId, qty) {
  if (qty <= 0) {
    await query("DELETE FROM character_inventory WHERE character_id=$1 AND item_id=$2", [characterId, itemId]);
  } else {
    await query(
      `INSERT INTO character_inventory (character_id, item_id, qty) VALUES ($1,$2,$3)
       ON CONFLICT (character_id, item_id) DO UPDATE SET qty=$3`,
      [characterId, itemId, qty]
    );
  }
}

module.exports = {
  loadOrCreateCharacter, saveCharacterCore, unlockSkill, grantAchievement, discoverZone,
  setInventoryQty, todayDateStr
};
