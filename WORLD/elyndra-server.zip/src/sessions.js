"use strict";
/**
 * socketId -> { character, phoenixState }. Wird von sockets.js beim
 * Verbinden/Trennen gepflegt und von server.js gelesen, wenn der Welt-Tick
 * einen Monsterangriff auf einen bestimmten Spieler anwenden muss.
 */
const sessions = new Map();

function register(socketId, session) { sessions.set(socketId, session); }
function unregister(socketId) { sessions.delete(socketId); }
function get(socketId) { return sessions.get(socketId); }

module.exports = { register, unregister, get, sessions };
