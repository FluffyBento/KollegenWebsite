"use strict";
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.ELYNDRA_JWT_SECRET;
if (!JWT_SECRET) {
  console.warn("[auth] WARNUNG: ELYNDRA_JWT_SECRET ist nicht gesetzt — Tokens können nicht sicher geprüft werden.");
}

/** Socket.io-Middleware: prüft das JWT, das die bestehende Website beim
 *  Spielstart ausstellt. Erwartet payload { userId, username, exp }. */
function socketAuthMiddleware(socket, next) {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error("Kein Token übergeben"));
    const payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
    if (!payload.userId || !payload.username) return next(new Error("Token-Payload unvollständig"));
    socket.user = { userId: String(payload.userId), username: String(payload.username) };
    next();
  } catch (err) {
    next(new Error("Ungültiges oder abgelaufenes Token: " + err.message));
  }
}

/** Express-Middleware für REST-Endpunkte, die denselben Website-Login verlangen. */
function restAuthMiddleware(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "Kein Token übergeben" });
    const payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
    req.user = { userId: String(payload.userId), username: String(payload.username) };
    next();
  } catch (err) {
    res.status(401).json({ error: "Ungültiges oder abgelaufenes Token" });
  }
}

/** Für den service-zu-service Aufruf von eurer Website an diesen Server
 *  (z.B. falls die Website Administration/Debug-Endpunkte nutzen soll). */
function serviceAuthMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token || token !== process.env.SERVICE_SECRET) {
    return res.status(401).json({ error: "Ungültiges Service-Secret" });
  }
  next();
}

module.exports = { socketAuthMiddleware, restAuthMiddleware, serviceAuthMiddleware, JWT_SECRET };
