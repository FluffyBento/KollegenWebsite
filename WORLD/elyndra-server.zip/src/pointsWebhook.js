"use strict";
/**
 * Ruft den Punkte-Gutschrift-Endpunkt eurer bestehenden Website auf.
 * WEBSITE_POINTS_URL zeigt in Produktion auf euren echten internen Endpunkt
 * (siehe backend-architektur.md, Abschnitt 4). Ist die Variable nicht gesetzt,
 * simuliert diese Funktion einen Erfolg — praktisch für lokale Tests, bevor
 * die Website-Seite fertig ist, aber NICHT für den echten Betrieb gedacht.
 */
async function callPointsWebhook(websiteUserId, points, idempotencyKey) {
  const url = process.env.WEBSITE_POINTS_URL;
  if (!url) {
    console.warn("[points] WEBSITE_POINTS_URL nicht gesetzt — simuliere Erfolg (nur für lokale Tests!).");
    return { ok: true, simulated: true };
  }
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.SERVICE_SECRET}` },
    body: JSON.stringify({ userId: websiteUserId, amount: points, reason: "elyndra_lumen_exchange", idempotencyKey })
  });
  if (!res.ok) throw new Error("Punkte-API antwortete mit Status " + res.status);
  return res.json();
}

module.exports = { callPointsWebhook };
