"use strict";
const { MONSTERS, ITEMS, findSkillNode, checkAchievements, BOUNTIES } = require("./gameData");
const { computeStats, xpNeed } = require("./stats");
const world = require("./world");
const characters = require("./characters");

const ATTACK_RANGE = 52;

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function grantXP(character, amount) {
  character.xp += amount;
  let leveledUp = false;
  while (character.xp >= xpNeed(character.level)) {
    character.xp -= xpNeed(character.level);
    character.level++;
    character.attr_points += 3;
    leveledUp = true;
  }
  if (leveledUp) {
    const stats = computeStats(character);
    character.hp = stats.maxHP;
    character.mp = stats.maxMP;
    character.stamina = stats.maxStamina;
  }
  return leveledUp;
}

function rollLoot(def, lootMult) {
  const drops = [];
  (def.loot || []).forEach(([itemId, chance, min, max]) => {
    if (Math.random() < chance * lootMult) {
      const qty = min + Math.floor(Math.random() * (max - min + 1));
      drops.push({ itemId, qty });
    }
  });
  return drops;
}

async function addLoot(character, drops) {
  for (const d of drops) {
    const row = character.inventory.find(r => r.id === d.itemId);
    const newQty = (row ? row.qty : 0) + d.qty;
    if (row) row.qty = newQty; else character.inventory.push({ id: d.itemId, qty: newQty });
    await characters.setInventoryQty(character.id, d.itemId, newQty);
  }
}

function bumpBounty(character, type, monsterType, amount) {
  amount = amount || 1;
  const today = characters.todayDateStr();
  if (character.daily.date !== today) character.daily = { date: today, bounties: {}, chestClaimed: false };
  BOUNTIES.forEach(b => {
    if (b.type !== type) return;
    if (type === "kill" && !b.match.includes(monsterType)) return;
    const cur = character.daily.bounties[b.id] || { progress: 0, claimed: false };
    if (cur.claimed) return;
    cur.progress = Math.min(b.count, cur.progress + amount);
    character.daily.bounties[b.id] = cur;
  });
}

async function persistAchievements(character, unlocked) {
  for (const a of unlocked) await characters.grantAchievement(character.id, a.id);
}

/** Nahkampf-Angriff: trifft alle lebenden Monster in Reichweite. Serverseitig
 *  berechnet, damit ein manipulierter Client nicht einfach beliebigen Schaden
 *  behaupten kann. */
async function resolveAttack(character, zoneId) {
  const stats = computeStats(character);
  const state = world.ensureZone(zoneId);
  const p = state.players.get(character.socketId);
  const origin = p || { x: character.x, y: character.y };
  const targets = state.monsters.filter(m => m.state !== "dead" && Math.hypot(m.x - origin.x, m.y - origin.y) < ATTACK_RANGE);
  if (targets.length === 0) return { hits: [] };

  const isCrit = Math.random() < stats.critBonus;
  const hits = [];
  for (const m of targets) {
    const def = MONSTERS[m.type];
    let dmg = Math.max(1, Math.round((stats.atk - def.def * 0.6) * (0.85 + Math.random() * 0.3)));
    if (isCrit) dmg = Math.round(dmg * 2);
    const result = await applyDamageToMonster(character, zoneId, m, dmg, isCrit);
    hits.push(result);
  }
  return { hits };
}

/** Fähigkeit einsetzen (aktiver Skillbaum-Knoten). */
async function resolveSkillUse(character, zoneId, skillId) {
  const node = findSkillNode(skillId);
  if (!node || node.type !== "active") return { ok: false, error: "Unbekannte Fähigkeit" };
  if (!character.unlocked_skills.includes(skillId)) return { ok: false, error: "Fähigkeit nicht freigeschaltet" };

  const stats = computeStats(character);
  if (character.mp < (node.mp || 0)) return { ok: false, error: "Nicht genug Mana" };
  if (character.stamina < (node.sp || 0)) return { ok: false, error: "Nicht genug Ausdauer" };

  character.mp -= (node.mp || 0);
  character.stamina -= (node.sp || 0);

  const state = world.ensureZone(zoneId);
  const p = state.players.get(character.socketId);
  const origin = p || { x: character.x, y: character.y };

  if (node.heal) {
    const amt = node.heal + stats.mag * 0.5;
    character.hp = clamp(character.hp + amt, 0, stats.maxHP);
    return { ok: true, heal: Math.round(amt), hp: character.hp };
  }

  const power = node.magic ? stats.mag : stats.atk;
  let targets;
  if (node.aoe) {
    targets = state.monsters.filter(m => m.state !== "dead" && Math.hypot(m.x - origin.x, m.y - origin.y) < node.radius);
  } else {
    targets = state.monsters
      .filter(m => m.state !== "dead" && Math.hypot(m.x - origin.x, m.y - origin.y) < 170)
      .sort((a, b) => Math.hypot(a.x - origin.x, a.y - origin.y) - Math.hypot(b.x - origin.x, b.y - origin.y))
      .slice(0, 1);
  }
  const hits = [];
  for (const m of targets) {
    const def = MONSTERS[m.type];
    let dmg = Math.max(1, Math.round((power * node.mult - def.def * 0.5) * (0.9 + Math.random() * 0.2)));
    if (node.crit) dmg = Math.round(dmg * 2);
    hits.push(await applyDamageToMonster(character, zoneId, m, dmg, !!node.crit));
  }
  return { ok: true, hits };
}

async function applyDamageToMonster(character, zoneId, monster, dmg, crit) {
  monster.hp -= dmg;
  const result = { monsterId: monster.id, dmg, crit, hp: Math.max(0, monster.hp), died: false };
  if (monster.hp <= 0) {
    result.died = true;
    result.outcome = await onMonsterDefeated(character, zoneId, monster);
  }
  return result;
}

async function onMonsterDefeated(character, zoneId, monster) {
  const def = MONSTERS[monster.type];
  world.killMonster(zoneId, monster.id);

  character.counters.kills++;
  if (def.elite) character.counters.elites++;
  bumpBounty(character, "kill", monster.type);
  const leveledUp = grantXP(character, def.xp);

  const stats = computeStats(character);
  const drops = rollLoot(def, stats.lootMult);
  await addLoot(character, drops);

  let uniqueClaimed = null;
  if (def.uniqueDrop) uniqueClaimed = await claimUniqueItem(character, def.uniqueDrop);
  if (def.boss) character.flags.dungeonBossDefeated = true;

  const unlockedAchievements = checkAchievements(character);
  await persistAchievements(character, unlockedAchievements);

  return {
    monsterName: def.name, xp: def.xp, leveledUp, newLevel: character.level,
    drops, uniqueClaimed, achievements: unlockedAchievements.map(a => a.id)
  };
}

/** Atomarer Claim für weltweit einmalige Gegenstände — der Primary-Key-
 *  Constraint auf unique_item_claims.item_id garantiert, dass niemals zwei
 *  Charaktere denselben einzigartigen Gegenstand bekommen, selbst bei
 *  gleichzeitigen Kills auf verschiedenen Servern/Prozessen. */
async function claimUniqueItem(character, itemId) {
  const { query } = require("./db");
  try {
    await query(
      "INSERT INTO unique_item_claims (item_id, claimed_by) VALUES ($1,$2)",
      [itemId, character.id]
    );
  } catch (err) {
    if (err.code === "23505") return { claimed: false, itemId }; // unique_violation = jemand war schneller
    throw err;
  }
  await addLoot(character, [{ itemId, qty: 1 }]);
  return { claimed: true, itemId };
}

/** Schaden durch ein Monster am Spieler — inkl. Phönixseele-Passiv und
 *  Respawn am Zonen-Spawnpunkt bei 0 HP. */
function applyMonsterAttackToPlayer(character, atk, spawnPoint, phoenixState) {
  const stats = computeStats(character);
  const dmg = Math.max(1, Math.round((atk - stats.def * 0.5) * (0.85 + Math.random() * 0.3)));
  character.hp = clamp(character.hp - dmg, 0, stats.maxHP);
  let downed = false, phoenixSaved = false;
  if (character.hp <= 0) {
    if (stats.phoenix && phoenixState.ready) {
      character.hp = 1;
      phoenixState.ready = false;
      phoenixSaved = true;
    } else {
      character.hp = Math.round(stats.maxHP * 0.5);
      character.x = spawnPoint.x; character.y = spawnPoint.y;
      downed = true;
    }
  }
  if (character.hp >= stats.maxHP) phoenixState.ready = true;
  return { dmg, hp: character.hp, downed, phoenixSaved };
}

module.exports = { resolveAttack, resolveSkillUse, grantXP, bumpBounty, applyMonsterAttackToPlayer, claimUniqueItem };
