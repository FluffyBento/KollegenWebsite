"use strict";
/**
 * Zentrale Spieldaten für den Server. ITEMS/RECIPES/MONSTERS/SKILL_TREES/
 * BOUNTIES/ZONES/SHOPS werden aus gameData.generated.json geladen — diese
 * Datei wird direkt aus dem Client (game.js/zones.js) extrahiert, damit
 * Client und Server nie auseinanderlaufen. Neu erzeugen mit:
 *
 *   node scripts/extract-game-data.js /pfad/zum/client/game.js /pfad/zu/zones.js
 *
 * ACHIEVEMENTS enthalten im Client kleine Funktionen (`check: p => ...`),
 * die sich nicht verlustfrei nach JSON exportieren lassen — deshalb hier
 * bewusst deklarativ (statPath/gte statt Funktion) neu formuliert.
 */
const path = require("path");
const raw = require(path.join(__dirname, "gameData.generated.json"));

const { ITEMS, RECIPES, MONSTERS, SKILL_TREES, BOUNTIES, ZONES, SHOPS, RARITY_COLOR, RARITY_LABEL } = raw;

// liest einen Pfad wie 'counters.kills' oder 'discovered.length' aus dem Charakter
function getPath(obj, dotted) {
  return dotted.split(".").reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

const ACHIEVEMENTS = [
  { id: "kills1", reward: 1, statPath: "counters.kills", gte: 1 },
  { id: "kills10", reward: 1, statPath: "counters.kills", gte: 10 },
  { id: "kills50", reward: 1, statPath: "counters.kills", gte: 50 },
  { id: "kills100", reward: 1, statPath: "counters.kills", gte: 100 },
  { id: "crafts1", reward: 1, statPath: "counters.crafts", gte: 1 },
  { id: "crafts10", reward: 1, statPath: "counters.crafts", gte: 10 },
  { id: "gathers20", reward: 1, statPath: "counters.gathers", gte: 20 },
  { id: "gathers50", reward: 1, statPath: "counters.gathers", gte: 50 },
  { id: "elites10", reward: 2, statPath: "counters.elites", gte: 10 },
  { id: "allZones", reward: 2, statPath: "discovered.length", gte: 6 },
  { id: "dungeonBoss", reward: 3, statPath: "flags.dungeonBossDefeated", gte: 1, boolFlag: true },
  { id: "level5", reward: 1, statPath: "level", gte: 5 },
  { id: "level10", reward: 1, statPath: "level", gte: 10 },
  { id: "level15", reward: 1, statPath: "level", gte: 15 },
  { id: "level20", reward: 1, statPath: "level", gte: 20 }
];

function achievementMet(def, character) {
  const v = getPath(character, def.statPath);
  if (def.boolFlag) return !!v;
  return typeof v === "number" && v >= def.gte;
}

/** Prüft alle Errungenschaften, verleiht Fähigkeitspunkte für neue, gibt die frisch
 *  freigeschalteten IDs zurück (für Toasts/Benachrichtigungen an den Client). */
function checkAchievements(character) {
  character.achievements = character.achievements || [];
  const unlocked = [];
  for (const def of ACHIEVEMENTS) {
    if (character.achievements.includes(def.id)) continue;
    if (achievementMet(def, character)) {
      character.achievements.push(def.id);
      character.skill_points = (character.skill_points || 0) + def.reward;
      unlocked.push(def);
    }
  }
  return unlocked;
}

function findSkillNode(skillId) {
  for (const key of Object.keys(SKILL_TREES)) {
    const n = SKILL_TREES[key].nodes.find(x => x.id === skillId);
    if (n) return n;
  }
  return null;
}

module.exports = {
  ITEMS, RECIPES, MONSTERS, SKILL_TREES, BOUNTIES, ZONES, SHOPS, RARITY_COLOR, RARITY_LABEL,
  ACHIEVEMENTS, getPath, achievementMet, checkAchievements, findSkillNode
};
