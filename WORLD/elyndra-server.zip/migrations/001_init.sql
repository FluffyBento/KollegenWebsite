-- =========================================================================
-- Elyndra Online — Migration 001: Grundschema
-- Ausführen mit:  psql "$DATABASE_URL" -f migrations/001_init.sql
-- =========================================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- für gen_random_uuid()

CREATE TABLE characters (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  website_user_id     TEXT UNIQUE NOT NULL,
  name                TEXT NOT NULL,
  color               TEXT NOT NULL DEFAULT '#c96b4a',
  level               INT NOT NULL DEFAULT 1,
  xp                  INT NOT NULL DEFAULT 0,
  attr_leben          INT NOT NULL DEFAULT 0,
  attr_verteidigung   INT NOT NULL DEFAULT 0,
  attr_magie          INT NOT NULL DEFAULT 0,
  attr_angriff        INT NOT NULL DEFAULT 0,
  attr_ausdauer       INT NOT NULL DEFAULT 0,
  attr_points         INT NOT NULL DEFAULT 3,
  skill_points        INT NOT NULL DEFAULT 0,
  gold_lumen          INT NOT NULL DEFAULT 40 CHECK (gold_lumen >= 0),
  hunger              REAL NOT NULL DEFAULT 100,
  thirst              REAL NOT NULL DEFAULT 100,
  hp                  REAL NOT NULL DEFAULT 100,
  mp                  REAL NOT NULL DEFAULT 30,
  stamina             REAL NOT NULL DEFAULT 100,
  zone_id             TEXT NOT NULL DEFAULT 'lobby',
  pos_x               REAL NOT NULL DEFAULT 750,
  pos_y               REAL NOT NULL DEFAULT 830,
  equipped_weapon     TEXT,
  equipped_armor      TEXT,
  equipped_accessory  TEXT,
  hotbar              JSONB NOT NULL DEFAULT '[null,null,null,null]',
  flags               JSONB NOT NULL DEFAULT '{}',       -- rangDoorbell, metFenn, gotKexGift, dungeonBossDefeated, ...
  buffs               JSONB NOT NULL DEFAULT '[]',        -- aktive Elixier-Effekte [{stat,mult,until}]
  counter_kills       INT NOT NULL DEFAULT 0,
  counter_crafts      INT NOT NULL DEFAULT 0,
  counter_gathers     INT NOT NULL DEFAULT 0,
  counter_elites      INT NOT NULL DEFAULT 0,
  daily_date          DATE NOT NULL DEFAULT CURRENT_DATE,
  daily_bounties      JSONB NOT NULL DEFAULT '{}',        -- {bountyId: {progress, claimed}}
  daily_chest_claimed BOOLEAN NOT NULL DEFAULT false,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE character_unlocked_skills (
  character_id  UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  skill_id      TEXT NOT NULL,
  unlocked_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (character_id, skill_id)
);

CREATE TABLE character_achievements (
  character_id     UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  achievement_id   TEXT NOT NULL,
  achieved_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (character_id, achievement_id)
);

CREATE TABLE character_discovered_zones (
  character_id  UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  zone_id       TEXT NOT NULL,
  discovered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (character_id, zone_id)
);

CREATE TABLE character_inventory (
  character_id  UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  item_id       TEXT NOT NULL,
  qty           INT NOT NULL CHECK (qty >= 0),
  PRIMARY KEY (character_id, item_id)
);

CREATE TABLE auction_listings (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id     UUID NOT NULL REFERENCES characters(id),
  item_id       TEXT NOT NULL,
  qty           INT NOT NULL CHECK (qty > 0),
  price_lumen   INT NOT NULL CHECK (price_lumen > 0),
  listed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  sold_at       TIMESTAMPTZ,
  buyer_id      UUID REFERENCES characters(id)
);
CREATE INDEX idx_auction_active ON auction_listings (item_id) WHERE sold_at IS NULL;

-- Weltweit wirklich nur einmal vergebbare Gegenstände. Der UNIQUE-Constraint
-- (item_id ist Primary Key) garantiert das serverseitig per DB-Constraint,
-- kein "letzter gewinnt"-Risiko mehr wie im Browser-Prototyp.
CREATE TABLE unique_item_claims (
  item_id       TEXT PRIMARY KEY,
  claimed_by    UUID NOT NULL REFERENCES characters(id),
  claimed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE realm_objects (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id      UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  grid_x        INT NOT NULL,
  grid_y        INT NOT NULL,
  item_id       TEXT NOT NULL,
  placed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner_id, grid_x, grid_y)
);

CREATE TABLE lumen_transactions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id      UUID NOT NULL REFERENCES characters(id),
  amount            INT NOT NULL,
  reason            TEXT NOT NULL,
  idempotency_key   TEXT UNIQUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE mailbox_entries (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id  UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  item_id       TEXT,
  qty           INT,
  amount_lumen  INT NOT NULL DEFAULT 0,
  claimed       BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_mailbox_unclaimed ON mailbox_entries (character_id) WHERE claimed = false;
